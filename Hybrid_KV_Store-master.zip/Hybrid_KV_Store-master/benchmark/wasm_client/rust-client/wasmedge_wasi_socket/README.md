# WasmEdge WASI Socket

This project provides a Rust SDK for network socket functions available in the WasmEdge Runtime. For Rust source code examples on how to use APIs in this SDK, please see the [examples](examples/README.md) folder.

* [HTTP Client example project](examples/http_client)
* [HTTP Server example project](examples/http_server)
