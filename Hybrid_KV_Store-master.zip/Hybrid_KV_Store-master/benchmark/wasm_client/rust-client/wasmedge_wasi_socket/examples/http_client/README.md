# WasmEdge WASI Socket Http Client Demo

## Build

```shell
cargo build --target wasm32-wasi --release
```

## Run

```shell
wasmedge target/wasm32-wasi/release/http_client.wasm
```
